![GitHub](https://img.shields.io/github/license/Valerie2807/library_managment)
![GitHub](https://img.shields.io/badge/coverage-100%25-green)
![GitHub](https://img.shields.io/badge/docs-passing-green)
![GitHub](https://img.shields.io/badge/release-v.4.0.0-green)
![GitHub](https://img.shields.io/badge/python-3.8-blue)
![GitHub](https://img.shields.io/badge/matplotlib-3.5.1-blue)
![GitHub](https://img.shields.io/badge/pillow-9.0.0-blue)
![GitHub](https://img.shields.io/badge/sphinx-4.4.0-blue)
![GitHub](https://img.shields.io/badge/tkinter-2.7.0-blue)
![GitHub](https://img.shields.io/badge/windows-success-green)
![GitHub](https://img.shields.io/badge/macOs-success-green)
![GitHub](https://img.shields.io/badge/sqlite3-3.37.2-blue)

Library Manangement system - Readers Hub application

Readers Hub is an application which keeps the record of the books in the library. Software team is required to build the software which makes the work easier for the librarian. It will help to track which book is issued and which book is available. 

Application requirements:
Programming language is python. 
A database can be any of  SQL based database. (Ex. Sqlite3 (database). 
For Graphical user interface(GUI) can be used packages like Tkinter and Pillow for supporting and manipulating images.

Test cases : https://docs.google.com/spreadsheets/d/1LU97CXCVvJbzNFYKsq6_k1KBa-AmeFEWsRXBeR_63gw/edit?usp=sharing

Requirments Readers Hub: https://docs.google.com/document/d/1P_YCB6PiT6E9ZvyglXNo-bw5LGQn6uJDmRAxhIVAt-w/edit?usp=sharing

