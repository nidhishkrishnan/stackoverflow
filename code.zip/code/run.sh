#!/bin/bash
docker run -it -e DISPLAY=$(/usr/sbin/ipconfig getifaddr en0):0 -v /tmp/.X11-unix:/tmp/.X11-unix:rw  library-managment


docker run -it -e DISPLAY=$DISPLAY:0 -v /tmp/.X11-unix:/tmp/.X11-unix:rw nidhishkrishnan/librarymanage